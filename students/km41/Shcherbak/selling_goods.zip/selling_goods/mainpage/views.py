from django.shortcuts import render, redirect
from products.models import Shop

def homepage(request):
    can_create_shop = False
    shop = None

    if request.user.is_authenticated and request.user.identifying == 'Shop':
        if not Shop.objects.filter(owner=request.user):
            can_create_shop = True
        else:
        	shop = Shop.objects.get(owner_id=request.user.id)
    template_name = 'homepage/homepage.html'

    return render(request, template_name, {'can_create_shop': can_create_shop, 'shop': shop})

