from django.conf.urls import url
from . import views
from django.contrib.auth import views as auth

urlpatterns = [

    url(r'^registration/$', views.registration, name='signup'),

    url(r'^login/$', auth.login, {'template_name': 'registration/login.html'}, name='login'),

    url(r'^logout/$', auth.logout, {'next_page': '/'}, name='logout'),

]
