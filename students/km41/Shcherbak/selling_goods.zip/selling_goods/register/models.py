from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings


CHOICES = (('Customer', 'Customer'), ('Shop', 'Shop'))

class Registration(AbstractUser):
    identifying = models.CharField(max_length=8,choices=CHOICES,default='Customer',)
    phone = models.CharField(max_length=50, null=True, blank=True)
    adress = models.CharField(max_length=50, null=True, blank=True)
    shop_name = models.CharField(max_length=50, null=True, blank=True)

    class Meta(object):
        unique_together = ('email',)
