from django import forms
from django.contrib.auth.forms import UserCreationForm

# from .models import Taxi
from .models import Registration

from django.forms.widgets import PasswordInput, TextInput


class RegistrationForm(UserCreationForm):
    username = forms.CharField(max_length=50, help_text='Username')
    first_name = forms.CharField(max_length=50, required=False, help_text='Optional')
    last_name = forms.CharField(max_length=50, required=False, help_text='Optional')
    email = forms.EmailField(max_length=50, help_text='Required',
        widget=TextInput(attrs={'class':'validate','placeholder': 'my_email@mail.com', 'pattern':"[A-Za-z0-9._]+@[A-Za-z0-9._]+\.[A-Za-z]{2,5}", 'title': "my_email@mail.com"}))
    phone = forms.CharField(max_length=13, required=False, help_text='Optional',
        widget=TextInput(attrs={'class':'validate','placeholder': '+380731654481', 'pattern':"^[0-9\-\+]{10,13}$", 'title': "+380731654481"}))
    adress = forms.CharField(max_length=50, required=False, help_text='Optional')
    shop_name = forms.CharField(max_length=50, required=False, help_text='Optional')

    class Meta:
        model = Registration
        fields = ('username', 'first_name', 'last_name', 'email', 'password1',
            'password2', 'identifying', 'phone', 'adress', 'shop_name')

    def save(self, commit=True):
        user = super(RegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.identifying = self.cleaned_data['identifying']
        user.phone = self.cleaned_data['phone']
        user.adress = self.cleaned_data['adress']
        user.shop_name = self.cleaned_data['shop_name']

        user.save()

        return user


# class TaxiForm(forms.ModelForm):
#     class Meta:
#         model = Taxi
#         exclude = ('owner', 'driving_from', 'driving_till')
