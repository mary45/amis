from django.views import View
from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db import connection
from django.db import transaction

from .forms import CreateShopForm, CreateProductItemForm
from .models import Shop, ProductItem, Order
from register.models import Registration


@method_decorator(login_required, name='dispatch')
class ShopViweset(View):

    def get(self, request, pk=None, *args, **kwargs):
        can_create_shop = False
        shop_owner = False
        if request.user.identifying == 'Shop':
            if not Shop.objects.filter(owner=request.user):
                can_create_shop = True

        if pk:

            shop = Shop.objects.raw('SELECT * FROM PRODUCTS_SHOP WHERE ID = {}'.format(pk))[0]
            # shop = Shop.objects.get(pk=pk)

            productitems = ProductItem.objects.filter(shop_id=shop.id)

            if shop.owner_id == request.user.id:
                shop_owner = True
            orders_for_shop = Order.objects.filter(shop_id=shop.id)

            context = {'shop': shop, 'productitems': productitems,
            'can_create_shop': can_create_shop, 'shop_owner': shop_owner,
            'orders_for_shop': orders_for_shop}
            return render(request, 'products/shop-details.html', context)

        else:
            shops = Shop.objects.all()
            productitems = ProductItem.objects.all()
            context = {'shops': shops, 'productitems': productitems,
            'can_create_shop': can_create_shop, 'shop_owner': shop_owner}
            return render(request, 'products/shops.html', context)

    def post(self, request, pk, *args, **kwargs):
        productitems_id = request.POST.getlist('productitem_id')
        productitems_values = request.POST.getlist('productitem')

        with transaction.atomic():
                    cursor = connection.cursor()
                    cursor.execute('SET TRANSACTION ISOLATION LEVEL SERIALIZABLE')

                    for prod_id, prod_values in zip(productitems_id, productitems_values):
                            if prod_values != 0:
                                Order.objects.create(user=request.user, shop_id=pk,
                                    product_item_id=prod_id, quantity=prod_values)

        orders = Order.objects.filter(user_id=request.user.id)
        context = {'orders': orders}
        return render(request, 'orders/user-order-details.html', context)


@method_decorator(login_required, name='dispatch')
class ProductItemViweset(View):

    def get(self, request, pk=None, *args, **kwargs):

        productitem = ProductItem.objects.get(pk=pk)
        context = {'productitem': productitem}
        return render(request, 'products/productitem-details.html', context)


@method_decorator(login_required, name='dispatch')
class CreateShopViweset(View):
    def get(self, request):
        can_create_shop = False
        if request.user.identifying == 'Shop':
            if not Shop.objects.filter(owner=request.user):
                can_create_shop = True
        form = CreateShopForm()
        return render(request, 'create-shop.html', {'form': form, 'can_create_shop': can_create_shop}) 


    def post(self, request):
        can_create_shop = False
        if request.user.identifying == 'Shop':
            if not Shop.objects.filter(owner=request.user):
                can_create_shop = True
        form = CreateShopForm(request.POST)
        if form.is_valid():

            shop = form.save(commit=False)
            shop.owner_id = request.user.id
            shop.save()

            return redirect(reverse('products:shop', args=(shop.id, )))

        return render(request, 'create-shop.html', {'form': form, 'can_create_shop': can_create_shop})

@method_decorator(login_required, name='dispatch')
class CreateProductItemViweset(View):
    def get(self, request, pk):
        shop = Shop.objects.get(pk=pk)
        form = CreateProductItemForm()
        return render(request, 'create-productitem.html', {'form': form}) 

    def post(self, request, pk):
        shop = Shop.objects.get(pk=pk)
        form = CreateProductItemForm(request.POST)
        if form.is_valid():

            productitem = form.save(commit=False)

            productitem.shop_id = shop.id
            productitem.save()

            return redirect(reverse('products:shop', args=(shop.id, )))

        return render(request, 'create-productitem.html', {'form': form})

@method_decorator(login_required, name='dispatch')
class OrdersViweset(View):
    def get(self, request, pk=None):

        if pk:
            orders = Order.objects.filter(user_id=pk)
        else:
            orders = Order.objects.filter(user_id=request.user.id)

        return render(request, 'orders/user-order-details.html', {'orders': orders}) 
