from django.conf.urls import url
from . import views


urlpatterns = [

    url(r'^shops/$', views.ShopViweset.as_view(), name='shops'),

    url(r'^shop/(?P<pk>\d+)/$', views.ShopViweset.as_view(), name='shop'),

    url(r'^productitem/(?P<pk>\d+)/$', views.ProductItemViweset.as_view(), name='productitem'),

    url(r'^shop/create/$', views.CreateShopViweset.as_view(), name='shop_creating'),

    url(r'^shop/(?P<pk>\d+)/productitem/create/$', views.CreateProductItemViweset.as_view(), name='productitem_creating'),

    url(r'^orders/$', views.OrdersViweset.as_view(), name='order_view'),

    url(r'^orders/(?P<pk>\d+)/$', views.OrdersViweset.as_view(), name='order_view'),

]
