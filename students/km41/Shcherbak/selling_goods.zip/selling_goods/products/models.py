from django.db import models
from django.conf import settings


class Shop(models.Model):
	owner = models.OneToOneField(settings.AUTH_USER_MODEL)
	name = models.CharField(max_length=50, null=True)
	place = models.CharField(max_length=100, blank=True, null=True)
	descrtiption = models.CharField(max_length=255, blank=True, null=True)
	USERNAME_FIELD = 'request.user.username'

	def __str__(self):
		return "{owner}'s shop".format(owner=self.owner)


class ProductItem(models.Model):
	shop = models.ForeignKey(Shop, blank=True, null=True, on_delete=models.SET_NULL)
	name = models.CharField(max_length=50)
	price = models.PositiveIntegerField()
	quantity = models.PositiveIntegerField()
	product_picture = models.ImageField(upload_to='productitems/', blank=True, 
	 	default='productitems/no_product.png')

	def __str__(self):
		return 'Product {name}'.format(name=self.name)

	class Meta:
		unique_together = (("name", "shop"),)


class Order(models.Model):
	order_time = models.DateTimeField(null=True)			# Trigger
	user = models.ForeignKey(settings.AUTH_USER_MODEL)
	shop = models.ForeignKey(Shop)
	product_item = models.ForeignKey(ProductItem, null=True)
	quantity = models.PositiveIntegerField()


	def __str__(self):
		return 'Order of user {user} from shop {shop} on {order_time}'.format(
			user=self.user, shop=self.shop, order_time=self.order_time)
