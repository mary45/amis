from django.contrib import admin

from .models import Shop, ProductItem, Order


admin.site.register(Shop)
admin.site.register(ProductItem)
admin.site.register(Order)
