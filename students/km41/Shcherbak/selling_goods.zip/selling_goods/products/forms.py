from django import forms
from .models import Shop, ProductItem


class CreateShopForm(forms.ModelForm):
    name = forms.CharField(max_length=30, required=True, help_text='Required')
    descrtiption = forms.CharField(max_length=30, required=False, help_text='Optional')
    place = forms.CharField(max_length=30, required=False, help_text='Optional')

    class Meta:
        model = Shop
        fields = ('name', 'descrtiption', 'place')


class CreateProductItemForm(forms.ModelForm):
    name = forms.CharField(max_length=30, required=True, help_text='Please, input name')
    price = forms.IntegerField(max_value=1000, min_value=1, required=True, help_text='Please, input price')
    quantity = forms.IntegerField(max_value=1000, min_value=1, required=True, help_text='Please, input quantity')

    class Meta:
        model = ProductItem
        fields = ('name', 'price', 'quantity', 'product_picture')
